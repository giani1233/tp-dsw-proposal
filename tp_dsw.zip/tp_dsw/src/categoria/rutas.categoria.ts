import { Router } from "express";
import { sanitizeCategoriaInput, findAll, findOne, add, update, remove} from "./controlador.categoria.js";

export const rutaCategoria = Router();

rutaCategoria.get('/', findAll)
rutaCategoria.get('/:id', findOne)
rutaCategoria.post('/', sanitizeCategoriaInput, add)
rutaCategoria.put('/:id', sanitizeCategoriaInput, update)
rutaCategoria.patch('/:id', sanitizeCategoriaInput, update)
rutaCategoria.delete('/:id', remove)