
export class Categoria {
    constructor(
        public id: number,
        public nombre: string,
    ) {}
}