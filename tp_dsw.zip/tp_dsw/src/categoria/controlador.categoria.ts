import { Request, Response, NextFunction, request } from 'express';
import { RepositorioCategoria } from './repositorio.categoria.js';
import { Categoria } from './entidad.categoria.js';

const repositorio = new RepositorioCategoria()

function sanitizeCategoriaInput(req: Request, res: Response, next: NextFunction){

    req.body.sanitizedInput = {
        id: req.body.id,
        nombre: req.body.nombre
    }
    Object.keys(req.body.sanitizedInput).forEach(key => {
        if(req.body.sanitizedInput[key] === undefined){
            delete req.body.sanitizedInput[key]
        }
    })
    next()
}

function findAll(req: Request, res: Response){
    res.json({data: repositorio.findall()})
}

function findOne(req: Request, res: Response){
    const id = parseInt(req.params.id)
    const categoria = repositorio.findone({id})
    if (!categoria) {
        return res.status(404).json({ error: 'Categoria no encontrada' }) 
    }
    res.json({data: categoria})
}

function add(req: Request, res: Response){
    const input = req.body.sanitizedInput
    const categoriaInput = new Categoria(input.id, input.nombre)
    const categoria = repositorio.add(categoriaInput)
    return res.status(201).send({Message: 'Categoria creada', data: categoria })
}

function update(req: Request, res: Response){
    req.body.sanitizedInput.id = parseInt(req.params.id)
    const categoria = repositorio.update(req.body.sanitizedInput)
    
    if (!categoria) {
        return res.status(404).json({ error: 'Categoria no encontrada' })
    }

    return res.status(200).send({message: 'Categoria actualizada', data: categoria})
}

function remove(req: Request, res: Response){
    const id = parseInt(req.params.id)
    const categoria = repositorio.delete({id})

    if (!categoria) {
        return res.status(404).json({ error: 'Categoria no encontrada' })
    } else {
        return res.status(200).send({message: 'Categoria eliminada'})
    }
}

export { sanitizeCategoriaInput, findAll, findOne, add, update, remove };