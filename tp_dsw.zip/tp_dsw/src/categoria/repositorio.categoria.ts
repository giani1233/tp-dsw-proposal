import { Repositorio } from "../shared/repositorio.js";
import { Categoria } from "./entidad.categoria.js";

const categorias =  [
    new Categoria(1, 'Fiesta Electronica'), ]

export class RepositorioCategoria implements Repositorio<Categoria>{
    public findall(): Categoria[] | undefined {
        return categorias;
    }

    public findone(item: {id: number }): Categoria | undefined {
        return categorias.find((categoria) => categoria.id === parseInt(item.id.toString()));
    }

    public add(item: Categoria): Categoria | undefined {
        categorias.push(item);
        return item;
    }

    public update(item: Categoria): Categoria | undefined {
        const categoriaIndex = categorias.findIndex((categoria) => categoria.id == parseInt(item.id.toString()));

        if (categoriaIndex !== -1) {
            categorias[categoriaIndex] = {...categorias[categoriaIndex], ...item}
        }
        return categorias[categoriaIndex]
    }

    public delete(item: {id: number }): Categoria | undefined {
        const categoriaIndex = categorias.findIndex((categoria) => categoria.id == parseInt(item.id.toString()))

        if (categoriaIndex !== -1) {
            const CategoriasBorradas = categorias[categoriaIndex]
            categorias.splice(categoriaIndex, 1)
            return CategoriasBorradas;
        }
    } 
}
